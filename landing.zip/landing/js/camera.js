(() => {
  'use strict';

  let mediaStream = null;

  function setStatus(msg){
    const el = document.getElementById('status');
    if(el) el.textContent = msg || '';
  }

  async function openCamera(){
    try{
      const panel = document.getElementById('cameraPanel');
      const video = document.getElementById('cameraVideo');
      const btnOpen = document.getElementById('btnAbrirCam');
      const btnClose = document.getElementById('btnCerrarCam');

      if(mediaStream){ return; }

      const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' }, audio:false });
      mediaStream = stream;
      video.srcObject = stream;

      if(panel) panel.hidden = false;
      if(btnOpen) btnOpen.hidden = true;
      if(btnClose) btnClose.hidden = false;
      setStatus('[No verificado] Cámara abierta (vista previa)');
    }catch(err){
      console.error(err);
      setStatus('[No verificado] No fue posible acceder a la cámara');
    }
  }

  async function closeCamera(){
    try{
      const panel = document.getElementById('cameraPanel');
      const video = document.getElementById('cameraVideo');
      const btnOpen = document.getElementById('btnAbrirCam');
      const btnClose = document.getElementById('btnCerrarCam');

      if(mediaStream){
        for(const track of mediaStream.getTracks()) track.stop();
        mediaStream = null;
      }
      if(video) video.srcObject = null;
      if(panel) panel.hidden = true;
      if(btnOpen) btnOpen.hidden = false;
      if(btnClose) btnClose.hidden = true;
      setStatus('');
    }catch(_){
      setStatus('');
    }
  }

  function showImagesTab(){
    const images = document.getElementById('imagesPanel');
    const camera = document.getElementById('cameraPanel');
    if(camera && !camera.hidden){ closeCamera(); }
    if(images) images.hidden = false;
    if(camera) camera.hidden = true;
  }

  function showCameraTab(){
    const images = document.getElementById('imagesPanel');
    const camera = document.getElementById('cameraPanel');
    if(images) images.hidden = true;
    if(camera) camera.hidden = false;
    // abrir cámara automáticamente al cambiar de pestaña
    openCamera();
  }

  function init(){
    const btnOpen = document.getElementById('btnAbrirCam');
    const btnClose = document.getElementById('btnCerrarCam');
    const btnTabImages = document.getElementById('btnTabImages');
    const btnTabCamera = document.getElementById('btnTabCamera');
    if(btnOpen) btnOpen.addEventListener('click', openCamera);
    if(btnClose) btnClose.addEventListener('click', closeCamera);
    if(btnTabImages) btnTabImages.addEventListener('click', showImagesTab);
    if(btnTabCamera) btnTabCamera.addEventListener('click', showCameraTab);
  }

  document.addEventListener('DOMContentLoaded', init, { once:true });

  // Expose for manual testing if needed
  window.CameraDemo = { openCamera, closeCamera, showImagesTab, showCameraTab };
})();
